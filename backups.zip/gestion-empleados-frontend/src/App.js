import EmpleadoForm from "./components/EmpleadoForm";

function App() {
  return (
    <div>
      <EmpleadoForm />
    </div>
  );
}

export default App;