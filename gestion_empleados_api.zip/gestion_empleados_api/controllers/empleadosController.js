import {
  obtenerTodos,
  obtenerPorId,
  insertar,
  actualizar,
  eliminar
} from '../Models/empleadosModel.js';

export async function listarEmpleados(req, res) {
  try {
    const empleados = await obtenerTodos();
    res.json(empleados);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener empleados' });
  }
}

export async function obtenerEmpleado(req, res) {
  try {
    const { id } = req.params;
    const empleado = await obtenerPorId(id);
    if (!empleado) {
      return res.status(404).json({ error: 'Empleado no encontrado' });
    }
    res.json(empleado);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener empleado' });
  }
}

export async function crearEmpleado(req, res) {
  try {
    const { nombre, apellido, id_area } = req.body;
    if (!nombre || !apellido || !id_area) {
      return res.status(400).json({ error: 'Faltan datos requeridos' });
    }
    const nuevoEmpleado = await insertar({ nombre, apellido, id_area });
    res.status(201).json(nuevoEmpleado);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear empleado' });
  }
}

export async function actualizarEmpleado(req, res) {
  try {
    const { id } = req.params;
    const { nombre, apellido, id_area } = req.body;
    if (!nombre || !apellido || !id_area) {
      return res.status(400).json({ error: 'Faltan datos requeridos' });
    }
    const actualizado = await actualizar(id, { nombre, apellido, id_area });
    if (!actualizado) {
      return res.status(404).json({ error: 'Empleado no encontrado' });
    }
    res.json({ mensaje: 'Empleado actualizado correctamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar empleado' });
  }
}

export async function eliminarEmpleado(req, res) {
  try {
    const { id } = req.params;
    const eliminado = await eliminar(id);
    if (!eliminado) {
      return res.status(404).json({ error: 'Empleado no encontrado' });
    }
    res.json({ mensaje: 'Empleado eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar empleado' });
  }
}