import mysql from 'mysql2/promise';

export const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'D6M7NR98XD3C*50', // ← pon tu contraseña si aplica
  database: 'gestion_empleados',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});