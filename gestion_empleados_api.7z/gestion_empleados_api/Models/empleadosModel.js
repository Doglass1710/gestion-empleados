import { pool } from '../db/connection.js';

export async function obtenerTodos() {
  const [rows] = await pool.query('SELECT * FROM empleados');
  return rows;
}

export async function obtenerPorId(id) {
  const [rows] = await pool.query('SELECT * FROM empleados WHERE id_empleado = ?', [id]);
  return rows[0];
}

export async function insertar({ nombre, apellido, id_area }) {
  const [result] = await pool.query(
    'INSERT INTO empleados (nombre, apellido, id_area) VALUES (?, ?, ?)',
    [nombre, apellido, id_area]
  );
  return { id_empleado: result.insertId, nombre, apellido, id_area };
}

export async function actualizar(id, { nombre, apellido, id_area }) {
  const [result] = await pool.query(
    'UPDATE empleados SET nombre = ?, apellido = ?, id_area = ? WHERE id_empleado = ?',
    [nombre, apellido, id_area, id]
  );
  return result.affectedRows > 0;
}

export async function eliminar(id) {
  const [result] = await pool.query('DELETE FROM empleados WHERE id_empleado = ?', [id]);
  return result.affectedRows > 0;
}