import express from 'express';
import empleadosRoutes from './empleados.js';
import areasRoutes from './areas.js';
import equiposRoutes from './equipos.js';
import usuariosRoutes from './usuarios.js';

const router = express.Router();

// Prefijos de las entidades
router.use('/empleados', empleadosRoutes);
router.use('/areas', areasRoutes);
router.use('/equipos', equiposRoutes);
router.use('/usuarios', usuariosRoutes);

export default router;