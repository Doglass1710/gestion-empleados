import express from 'express';
import {
  listarEmpleados,
  obtenerEmpleado,
  crearEmpleado,
  actualizarEmpleado,
  eliminarEmpleado
} from '../controllers/empleadosController.js';

const router = express.Router();

// Listar todos los empleados
router.get('/', listarEmpleados);

// Obtener un empleado por ID
router.get('/:id', obtenerEmpleado);

// Crear un nuevo empleado
router.post('/', crearEmpleado);

// Actualizar un empleado existente
router.put('/:id', actualizarEmpleado);

// Eliminar un empleado
router.delete('/:id', eliminarEmpleado);

export default router;